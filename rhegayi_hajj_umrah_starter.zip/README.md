# ڕێگای حەج و عومرە — Starter Project

This is a **starter scaffold**, not a deployed or production-ready application.

## Structure
- `backend/`: NestJS API starter with Prisma schema and tenant-aware auth outline.
- `mobile/`: Flutter starter app with Kurdish Sorani RTL shell.
- `docs/`: implementation and security notes.

## Prerequisites
- Node.js LTS + npm
- Flutter stable SDK
- PostgreSQL 15+

## Backend setup
1. `cd backend`
2. `cp .env.example .env` and set a strong `JWT_SECRET` and database URL.
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. `npm run start:dev`

The starter currently exposes a health endpoint only. Authentication, tenant isolation, and business APIs must be implemented and security-reviewed before real data is used.

## Mobile setup
1. `cd mobile`
2. `flutter pub get`
3. `flutter run`

## Important security requirements before production
- Enforce tenant isolation in every query and PostgreSQL RLS policies.
- Derive tenant identity from verified authentication, never from untrusted request body values.
- Hash passwords with Argon2id or bcrypt; use short-lived access tokens and secure refresh-token rotation.
- Store passport/visa files in private object storage with short-lived signed URLs.
- Add role/permission checks, audit logs, backups, rate limits, monitoring, and tests.
- Do not use real pilgrim passport data in development.
